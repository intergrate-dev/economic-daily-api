package com.itstyle.jwt.generCode.service;

import com.itstyle.jwt.generCode.entity.Member;
import java.lang.String;
import org.springframework.data.domain.Page;

/**
 * @Author:LiuBingXu
 * @Date: 2019/05/06
 */
public interface MemberServer {
  Member saveOrUpdate(Member member);

  Member getMemberById(String id);

  boolean deleteMemberByIds(String ids);

  Page pageList(Member member, int page, int pageSize);
}

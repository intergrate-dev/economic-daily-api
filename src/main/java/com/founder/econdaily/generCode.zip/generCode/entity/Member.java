package com.itstyle.jwt.generCode.entity;

import java.lang.Integer;
import java.lang.String;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.Data;

/**
 *  @Author:LiuBingXu
 *  @Description: 
 *  @Date: 2019/05/06.
 *  @Modified by
 */
@Data
@Entity
@Table(
    name = "dev_member"
)
public class Member {
  @Column(
      name = "id"
  )

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  @Column(
      name = "name"
  )
  private String name;

  @Column(
      name = "desc"
  )
  private String desc;
}

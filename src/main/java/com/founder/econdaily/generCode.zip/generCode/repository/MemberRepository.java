package com.itstyle.jwt.generCode.repository;

import com.itstyle.jwt.generCode.entity.Member;
import java.lang.String;
import jpa.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import javax.management.openmbean.CompositeData;

/**
 * @Author:LiuBingXu
 * @Date: 2019/05/06
 */
@Repository
public interface MemberRepository extends BaseRepository<Member, String> {
    Member findById(String id);
}

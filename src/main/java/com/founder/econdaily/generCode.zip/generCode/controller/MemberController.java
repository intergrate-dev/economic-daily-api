package com.itstyle.jwt.generCode.controller;

import com.itstyle.jwt.generCode.entity.Member;
import com.itstyle.jwt.generCode.service.MemberServer;
import java.lang.String;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author:LiuBingXu
 * @Date: 2019/05/06
 */
@RestController
public class MemberController {
  @Autowired
  public MemberServer memberServer;

  @PostMapping("/member/add")
  public ResponseEntity add(Member member) {
    return ResponseEntity.ok(memberServer.saveOrUpdate(member));
  }

  @PostMapping("/member/delByids")
  public ResponseEntity delByids(String ids) {
    return ResponseEntity.ok(memberServer.deleteMemberByIds(ids));
  }

  @PostMapping("/member/info/{id}")
  public ResponseEntity info(@PathVariable String id) {
    return ResponseEntity.ok(memberServer.getMemberById(id));
  }

  @PostMapping("/member/pageList")
  public Page pageListMethod(Member member, int page, int pageSize) {
    return memberServer.pageList(member, page, pageSize);
  }
}

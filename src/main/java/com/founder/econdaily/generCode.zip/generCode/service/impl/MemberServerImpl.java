package com.itstyle.jwt.generCode.service.impl;

import com.itstyle.jwt.generCode.entity.Member;
import com.itstyle.jwt.generCode.repository.MemberRepository;
import com.itstyle.jwt.generCode.service.MemberServer;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.persistence.criteria.Predicate;
import jpa.autocode.util.UUIDUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/**
 * @Author:LiuBingXu
 * @Date: 2019/05/06
 */
@Service
@Transactional
public class MemberServerImpl implements MemberServer {
  @Autowired
  private MemberRepository memberRepository;

  @Override
  public Member saveOrUpdate(Member member) {
      if (StringUtils.isEmpty(member.getId())) {
      member.setId(UUIDUtils.getUUID());
      }
    return memberRepository.save(member);
  }

  @Override
  public Member getMemberById(String id) {
      return memberRepository.findById(id );
  }

  @Override
  public boolean deleteMemberByIds(String ids) {
      String[] idArr = ids.split(",");
      memberRepository.batchDelete(Arrays.asList(idArr));
      return true;
  }

  public Specification toPredicate(Member member) {
     return (Specification<Member>) (root, criteriaQuery, criteriaBuilder) -> {
         List<Predicate> predicate = new ArrayList<>();
         if (org.apache.commons.lang3.StringUtils.isNotBlank(member.getId())) {
             predicate.add(criteriaBuilder.equal(root.get("id"), member.getId()));
         }
         return criteriaQuery.where(predicate.toArray(new Predicate[predicate.size()])).getRestriction();
     };
  }

  @Override
  public Page pageList(Member member, int page, int pageSize) {
      Sort sort = Sort.by(Sort.Direction.DESC, "id");
      Pageable pageable = PageRequest.of(page, pageSize, sort);
      return memberRepository.pageList(pageable, toPredicate(member));
  }
}

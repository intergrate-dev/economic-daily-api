package com.founder.econdaily.modules.historySource.service.impl;

import com.founder.econdaily.common.util.DateParseUtil;
import com.founder.econdaily.modules.historySource.service.HistorySourceService;
import com.founder.econdaily.modules.magazine.entity.MagazineArticle;
import com.founder.econdaily.modules.magazine.repository.MagazineAttachmentRepository;
import com.founder.econdaily.modules.magazine.repository.MagazineRepository;
import com.founder.econdaily.modules.newspaper.entity.PaperArticle;
import com.founder.econdaily.modules.newspaper.repository.NewsPaperRepository;
import com.founder.econdaily.modules.newspaper.repository.PaperAttachmentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class HistorySourceImpl implements HistorySourceService {

    /**
     * 日志实例
     */
    private static final Logger logger = LoggerFactory.getLogger(HistorySourceImpl.class);

    @Autowired
    private NewsPaperRepository newsPaperRepository;

    @Autowired
    private MagazineRepository magazineRepository;

    @Autowired
    private PaperAttachmentRepository paperAttachmentRepository;

    @Autowired
    private MagazineAttachmentRepository magazineAttachmentRepository;

    @Override
    public Map<String, Object> queryPaperArticles(Integer pageNo, Integer limit) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        List<PaperArticle> paperArticles = newsPaperRepository.queryPaperArticles(pageNo, limit);
        for (PaperArticle paperArticle : paperArticles) {
            paperArticle.setPic(paperAttachmentRepository.findCoverByArticleIdAndLibId(paperArticle.getId(), PaperArticle.ARTICLE_LIB_ID));
        }
        map.put("list", paperArticles);
        map.put("totalCount", newsPaperRepository.queryPaperArticleTotal());
        return map;
    }

    @Override
    public Map<String, Object> queryMagazineArticles(Integer pageNo, Integer limit) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        List<MagazineArticle> magazineArticles = magazineRepository.queryMagazineArticles(pageNo, limit);
        for (MagazineArticle magazineArticle : magazineArticles) {
            // a_picBig  期刊存储;imported/jingji\2015\01\01\Figure-0176-01.jpg
            // http://172.17.41.49/magazine/jjrb/pic/200502/18/figure_0025_0042.jpg
            magazineArticle.setPic(magazineAttachmentRepository.findCoverByArticleIdAndLibId(magazineArticle.getId(), MagazineArticle.ARTICLE_LIB_ID,
                    DateParseUtil.dateToStringWithSplit(magazineArticle.getPubTime())));
        }
        map.put("list", magazineArticles);
        map.put("totalCount", magazineRepository.queryMagazineArticleTotal());
        return map;
    }


}

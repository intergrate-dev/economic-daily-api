package com.founder.econdaily.modules.historySource.controller;

import com.founder.ark.common.utils.bean.ResponseObject;
import com.founder.econdaily.common.constant.SystemConstant;
import com.founder.econdaily.common.controller.BaseController;
import com.founder.econdaily.common.entity.PageResult;
import com.founder.econdaily.common.util.RegxUtil;
import com.founder.econdaily.modules.historySource.config.PlatformParamConfig;
import com.founder.econdaily.modules.historySource.service.HistorySourceService;
import com.founder.econdaily.modules.newspaper.entity.NewsPaperParam;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import javafx.application.Platform;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

@Api(tags = "历史资源接口")
@RestController
@RequestMapping(value = "/historySource")
public class HistorySourceController extends BaseController {

    private static final Logger logger = LoggerFactory.getLogger(HistorySourceController.class);
    @Autowired
    private HistorySourceService historySourceService;

    /*@ApiOperation(value = "电子报文章资源")
    @RequestMapping(value = "/articles/query", method = RequestMethod.POST)
    public ResponseObject queryPaperArticles(@RequestParam(name = "pageNo", required = false) Integer pageNo,
                                        @RequestParam(name = "limit", required = false) Integer limit) throws Exception {
        PageResult result = new PageResult();
        Map<String, Object> queryMap = historySourceService.queryPaperArticles(pageNo, limit);
        result.setPageNo(pageNo);
        result.setPageSize(limit);
        result.setResult((List) queryMap.get("list"));
        result.setTotalCount((Long) queryMap.get("totalCount"));
        return ResponseObject.newSuccessResponseObject(result, SystemConstant.REQ_SUCCESS);
    }

    @ApiOperation(value = "期刊文章资源")
    @RequestMapping(value = "/magazines/query", method = RequestMethod.POST)
    public ResponseObject queryMagazineArticles(@RequestParam(name = "pageNo", required = false) Integer pageNo,
                                        @RequestParam(name = "limit", required = false) Integer limit) throws Exception {
        PageResult result = new PageResult();
        Map<String, Object> queryMap = historySourceService.queryMagazineArticles(pageNo, limit);
        result.setPageNo(pageNo);
        result.setPageSize(limit);
        result.setResult((List) queryMap.get("list"));
        result.setTotalCount((Long) queryMap.get("totalCount"));
        return ResponseObject.newSuccessResponseObject(result, SystemConstant.REQ_SUCCESS);
    }*/

    /*@ApiOperation(value = "电子报原件下载")
    @GetMapping(value = "/newspaper/download/{paperCode}/{plDate}")*/
    public ResponseObject download(@Valid NewsPaperParam param, HttpServletRequest request, HttpServletResponse response) throws Exception {
        PageResult result = new PageResult();
        //String rootPath = "D:/z-files/paper/";
        String zipBasePath = this.extractPath(param, PlatformParamConfig.configsMap.get(PlatformParamConfig.PAPER_ROOT));

        String path = zipBasePath;
        Map<String, List<String>> map = new HashMap<String, List<String>>();
        this.recursion(path, map);

        String fileName = param.getPaperCode().concat("_").concat(param.getPlDate()).concat(".zip");
        response.setContentType("text/html; charset=UTF-8");
        response.setContentType("application/x-msdownload;");
        response.setHeader("Content-disposition", "attachment;filename=".concat(fileName));
        OutputStream out = response.getOutputStream();

        try {
            String pdfZip = zipBasePath.concat("pdf.zip");
            this.queryFilesAndZip(map.get("pdfList"), pdfZip);
            String xmlZip = zipBasePath.concat("xmlZip.zip");
            this.queryFilesAndZip(map.get("xmlList"), xmlZip);
            String contentAttach = zipBasePath.concat("contentAttach.zip");
            this.queryFilesAndZip(map.get("contAttList"), contentAttach);

            List<String> files = new ArrayList<String>();
            files.add(pdfZip);
            files.add(xmlZip);
            files.add(contentAttach);

            String compressFile = zipBasePath.concat("compress-files.zip");
            this.queryFilesAndZip(files, compressFile);
            writeOutputWithChannel(new FileInputStream(new File(compressFile)), out, true);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return ResponseObject.newSuccessResponseObject(result, SystemConstant.REQ_SUCCESS);
    }

    private void queryFilesAndZip(List<String> list, String zipFileName) throws IOException {
        File zip = new File(zipFileName);
        if (!zip.exists()) {
            zip.createNewFile();
        }

        /* 创建zip文件输出流 */
        InputStream fis = null;
        ZipOutputStream zos = null;
        try {
            FileOutputStream fos = new FileOutputStream(zip);
            zos = new ZipOutputStream(fos);

            /* 循环读取文件路径集合，获取每一个文件的路径（将文件一个一个进行压缩） */
            for (String fp : list) {
                //File f = new File(fp); // 根据文件路径创建文件
                //this.zipFile(f, zos); // 将每一个文件写入zip文件包内，即进行打包
                this.fileTransToZip(new File(fp), zos);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (zos != null) {
                zos.close();
            }
        }
    }


}

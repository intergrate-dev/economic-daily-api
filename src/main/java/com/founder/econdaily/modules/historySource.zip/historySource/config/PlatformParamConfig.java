package com.founder.econdaily.modules.historySource.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.util.HashMap;

/**
 * Created by yuan-pc on 2018/3/27.
 */
//@Component
@Configuration
public class PlatformParamConfig {
    public static final HashMap<String, String> configsMap = new HashMap<String, String>();
    public static final String PAPER_ROOT = "paperRoot";

    @Value("${platform.dev.paperRootPath}")
    private String paperRootPathDev;

    @Value("${platform.prod.paperRootPath}")
    private String paperRootPathProd;


    @Bean
    public static PropertySourcesPlaceholderConfigurer properties() {
        PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
        yaml.setResources(new ClassPathResource("define.yml"));
        propertySourcesPlaceholderConfigurer.setProperties(yaml.getObject());
        return propertySourcesPlaceholderConfigurer;
    }

    @Bean
    @Profile("dev")
    public String getPropertyConfigDev() {
        configsMap.put(PAPER_ROOT, paperRootPathDev);
        return null;
    }

    @Bean
    @Profile("prod")
    public String getPropertyConfigProd() {
        configsMap.put(PAPER_ROOT, paperRootPathProd);
        return null;
    }

    @Bean
    public String getPropertyConfig() {
        return null;
    }



}
